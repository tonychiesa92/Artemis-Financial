package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController {
	private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();

	private String getHash(String input) {
		try {
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			byte[] messageDigestMD5 = messageDigest.digest();
			return bytesToHex(messageDigestMD5);
		} catch (NoSuchAlgorithmException error) {
			error.printStackTrace();
		}
		return input;
	}

	public static String bytesToHex(byte[] bytes) {
		char[] hexChars = new char[bytes.length * 2];
		for (int i = 0; i < bytes.length; i++) {
			int x = bytes[i] & 0xFF;
			hexChars[i * 2] = HEX_ARRAY[x >>> 4];
			hexChars[i* 2 + 1] = HEX_ARRAY[x & 0x0F];
		}
		return new String(hexChars);
	}

	@RequestMapping("/hash")
	public String myHash() {
		String data = "Tony Chiesa Check Sum";
		String hash = getHash(data);
		return "<p>data: " + data + "</p><p>Cipher Used Is SHA-256 Value: " + hash;
	}
	
}